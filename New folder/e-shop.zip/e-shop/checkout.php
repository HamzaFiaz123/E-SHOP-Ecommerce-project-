<?php
include "partials/links.php";
include "partials/header.php";
?>

<div class="container">
    <div class="row">
        <div class="col-lg-8">
            <div class="form-group">
                <label for="">Name</label>
                <input type="text" class="form-control" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="email" class="form-control" placeholder="Enter your email">
            </div>
            <div class="form-group">
                <label for="">City</label>
                <input type="text" class="form-control" placeholder="Enter your city">
            </div>
            <div class="form-group">
                <label for="">Address</label>
                <input type="text" class="form-control" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="">Post code</label>
                <input type="number" class="form-control" placeholder="Enter your post code">
            </div>
            <div class="form-group">
                <label for="">Phone</label>
                <input type="text" class="form-control" placeholder="Enter your phone">
            </div>
            <div class="form-group">
                <a href="craete_account.php">Don't have an account. Lets create it</a>
            </div>
        </div>
        <div class="col-lg-4 border py-3 px-3">
            <h3 class="mb-3">Your Order</h3>
            <h5 class="mb-3">Products</h5>
            <hr>
            <div class="mb-2 d-flex">
                <label for="">Black T-shirt</label>
                <p class="ml-auto">67$</p>
            </div>
            <div class="mb-2 d-flex">
                <label for="">Trouser</label>
                <p class="ml-auto">23$</p>
            </div>
            <div class="mb-3 d-flex">
                <label for="">Subtotal</label>
                <p class="ml-auto">67$</p>
            </div>
            <h5 class="mb-3">Shipping</h5>
            <input type="radio">
            <label for="">Local</label><br>
            <input type="radio">
            <label for="">Flat Rate</label>
            <hr>
            <div class="mb-3 d-flex">
                <label for="">Total</label>
                <p class="ml-auto">34$</p>
            </div>
            <h5 class="mb-3">Payments Method</h5>
            <a href="#" class="btn btn-primary mb-3">Pay By Paypal</a>
            <a href="place_order.php" class="btn btn-dark w-100" data-toggle="modal" data-target="#myModal1">Place Order</a>

            <!-- The Modal -->
            <div class="modal fade" id="myModal1">
            <div class="modal-dialog">
                <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Order Placed</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <a href="cus_orders" class="text-primary text-decoration-none">To see your order detials click here</a>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

                </div>
            </div>
            </div>  
        </div>
    </div>
</div>





<?php
include "partials/footer.php";
?>