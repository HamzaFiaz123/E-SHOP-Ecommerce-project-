<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  
</body>
</html>

<body>
  <div class="container-fluid bg-primary">
    <div class="container">
      <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <a class="navbar-brand" href="#">Welcome To E-Shop</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav header_ul m-auto">
            <li>
              <a href="index.php">Home</span></a>
            </li>
            <li>
              <a  href="account.php">login</a>
            </li>
            <li>
              <a  href="contact.php">Contact</a>
            </li>
            <li>
              <a  href="contact.php">About</a>
            </li>
            <li>
              <a  href="customer_account.php">Account</a>
            </li>
          </ul>
          <div class="social_icons">
              <i class="fa fa-facebook text-white px-2"></i>
              <i class="fa fa-whatsapp text-white px-2"></i>
              <i class="fa fa-twitter text-white px-2"></i>
            </div>
        </div>
      </nav>
    </div>
  </div>










  <div class="container my-4">
    <div class="row align-items-center">
      <div class="col-lg-2 col-md-2 col-sm-5">
        <a href="index.php " style="color:black" class="text-decoration-none"><h4 class="font-weight-bold">E-SHOP</h4></a>
      </div>
      <div class="col-lg-7 col-md-6">
        <div style="border-radius:40px;" class="border px-3 d-flex ha_search_box">
          <div id="width-70" class="border-right">
            <input type="text" placeholder="Search" name="" class="form-controll" id="ha_cus_field">
          </div>
          <div class="dropdown border-right">
            <button type="button" class="btn dropdown-toggle" data-toggle="dropdown">
              All Categories
            </button>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Mens</a>
              <a class="dropdown-item" href="#">Womens</a>
              <a class="dropdown-item" href="#">Childerns</a>
            </div>
          </div>
          <div class="ml-2">
            <i class="fa fa-search text-dark"></i>
          </div>
          <div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-7 d-flex ha-call-box">
        <div class="d-flex justify-content-center align-items-center">
          <i class="fa fa-phone text-primary mr-3" id="width26"></i>
          <h6>Call us now<br><span>03061546874</span></h6>
        </div>
        <div>
          <i class="fa fa-heart text-primary mx-2"  id="width26"></i>
          <a href="cart.php"><i class="fa fa-shopping-bag mx-2" id="width26"></i></a>
        </div>
      </div>
    </div>
  </div>
  </div>
</body>


  