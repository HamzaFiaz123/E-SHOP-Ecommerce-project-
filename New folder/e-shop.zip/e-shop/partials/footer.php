


<footer class="container-fluid">
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <h5 class="mb-3 ha_comp_name">About Us</h5>
          <p class="foot-option-clr">
            E-SHOP here you can use rows and columns to organize your footer content. Lorem ipsum
            dolor sit amet, consectetur adipisicing elit.
          </p>
        </div>
        <div class="col-lg-3">
          <h5 class="mb-3 ha_comp_name">Contact Info</h5>
          <span class="foot-option-clr">
            <p class="ha_comp_name">ADDRESS:</p>
            <p class="foot-option-clr ml-2">123 Street Name, City, England</p>
            <p class="ha_comp_name">Phone Number:</p>
            <p class="foot-option-clr ml-2">0345 64944837</p>
            <p class="ha_comp_name">Email:</p>
            <p class="foot-option-clr ml-2">info@example.com</p>
          </span>
        </div>
        <div class="col-lg-3">
          <h5 class="mb-3 ha_comp_name">Customer Service</h5>
          <span class="foot-option-clr">
            <p class="foot-option-clr">Help</p>
            <p class="foot-option-clr">Shipment</p>
            <p class="foot-option-clr">Orders</p>
            <p class="foot-option-clr">Login</p>
            <p class="foot-option-clr">Categories</p>
            </p>
          </span>
        </div>
        <div class="col-lg-3">
          <h5 class="mb-3 ha_comp_name">Popular Tags</h5>
          <p class="foot-option-clr d-inline-block border p-1 m-2">Black</p>
          <p class="foot-option-clr d-inline-block border p-1 m-2">Bags</p>
          <p class="foot-option-clr d-inline-block border p-1 m-2">Men</p>
          <p class="foot-option-clr d-inline-block border p-1 m-2">Clothes</p>
          <p class="foot-option-clr d-inline-block border p-1 m-2">Womens</p>
          <p class="foot-option-clr d-inline-block border p-1 m-2">Watches</p>
          <p class="foot-option-clr d-inline-block border p-1 m-2">Home</p>
        </div>
      </div>
    </div>
    <hr color="white">
    <h5 class="text-white text-center">Copyrights @2022 Developed by Hamza fiaz</h5>
  </footer>