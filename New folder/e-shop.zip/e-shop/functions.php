<?php

include "config/db.php";
function getIPAddress()
{
    //whether ip is from the share internet  
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    //whether ip is from the remote address  
    else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function show_products()
{
    include "config/db.php";
    $sql_pro_show = "SELECT * FROM products";
    $result = mysqli_query($conn, $sql_pro_show);
    if (mysqli_num_rows($result) >= 1) {
        while ($row = mysqli_fetch_array($result)) {
            $pro_id = $row['id'];
            $pro_name = $row['prod_name'];
            $pro_price = $row['prod_price'];
            $pro_image = $row['prod_image'];
            echo '<div class="col-lg-3 col-md-3 col-sm-6">
                <div>
                  <img src="upload-images/' . $pro_image . ' " class="img-fluid mb-2">
                  <div>
                    <a href="product detrails.html"class="text-dark d-block font-weight-bold my-2">' . $pro_name . ' </a>
                    <i class="fa fa-star general-clr"></i>
                    <i class="fa fa-star general-clr"></i>
                    <i class="fa fa-star general-clr"></i>
                    <i class="fa fa-star general-clr"></i>
                    <i class="fa fa-star general-clr"></i>
                    <h5 class="my-2"> ' . $pro_price . '$</h5>
                    <a href=" addcart.php?pro_id=' . $pro_id . '" class="btn btn-primary btn-block my-2">Add to cart</a>
                  </div>
                </div>
              </div>';
        }
    }
}

function register_user()
{
    include "config/db.php";
    if (isset($_POST["login_btn"])) {
        $login_email = $_POST["login_email"];
        $login_pass = $_POST["login_pass"];
        $regt_sql = " SELECT * FROM customer_account WHERE customer_email = '$login_email' AND customer_password = '$login_pass'";
        $_SESSION['email'] = $login_email;
        $result = mysqli_query($conn, $regt_sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) > 0) {
            echo
                "
                <div class='alert alert-success'>Successfully login</div>
                  <script> 
                    alert('login');
                    window.location.replace('customer_account.php');
                  </script>";
        } else {
            echo
                "<div class='alert alert-danger'>User Not Registered</div>";
        }
    }
}


function login_user()
{
    include "config/db.php";
    if (isset($_POST['register_btn'])) {
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $reg_sql = "insert into customer_account (customer_email, customer_password) VALUES ('$email', '$pass')";
        $result = mysqli_query($conn, $reg_sql);
        if ($result) {
            echo "<div class='alert alert-success'>Successfully register</div>";
        } else {
            echo "<div class='alert alert-danger'>Not successfull, try again</div>";
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}

function addtocart()
{
    include "config/db.php";
    $p_id = $_GET['pro_id'];
    $ip_add = getIPAddress();
    $cart_check = "SELECT * FROM cart where ip_add='$ip_add' AND product_id='$p_id'";
    $query_result = mysqli_query($conn, $cart_check);
    $row = mysqli_fetch_array($query_result);
    $qty = $row['qty'];
    $count = mysqli_num_rows($query_result);
    if ($count > 0) {
        echo "<div class='alert alert-success'>product already in cart</div>";
    } else {
        $insert_cart = "insert into cart (product_id , ip_add , qty ) values ('$p_id' , '$ip_add' , '1' )";
        $result = mysqli_query($conn, $insert_cart);
        if ($result) {
            echo "<div class='alert alert-success'>Successfully add to cart</div>";
        } else {
            echo "<div class='alert alert-danger'>Not successfull, try again</div>";
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}



?>