<?php
  include "config/db.php";
  include "functions.php";
  
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>E-shop</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="style/css.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>


<?php
  include "partials/header.php";
?>



  <div class="container-fluid my-3">
    <div class="container">
      <div class="row border">
        <div class="col-lg-4 col-md-12">
          <div class="py-4 px-3">
            <div class="border-right">
              <h6>FREE SHIPPING & RETURN</h6>
              <p>Free shipping on all orders over $99</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-12">
          <div class="py-4 px-3 ">
            <div class="border-right">
              <h6>FREE SHIPPING & RETURN</h6>
              <p>Free shipping on all orders over $99</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-12">
          <div class="py-4 px-3">
            <div>
              <h6>FREE SHIPPING & RETURN</h6>
              <p>Free shipping on all orders over $99</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <div class="container-fluid my-3">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-12">
          <div>
            <ul class="bros_catg_ul border">
              <li style="background-color: #f5f5f5;">Browse Categories</li>
              <li class="general_bg_clr"><a href="index.php" style="color: white!important">Home</a></li>
              <li class="border-bottom"><a href="index.php" class="general_text_clr">Shop</a></li>
              <li class="border-bottom"><a href="index.php" class="general_text_clr">Features</a></li>
              <li class="border-bottom"><a href="index.php" class="general_text_clr">Mens</a></li>
              <li class="border-bottom"><a href="index.php" class="general_text_clr">Womens</a></li>
              <li class="border-bottom"><a href="index.php" class="general_text_clr">Login</a></li>
            </ul>
          </div>
        </div>

        <div class="col-lg-9 col-md-12 Hf_slider_box ">
          <div>
            <h5 style="color: rgba(255,255,255,0.7);">Find the Boundaries. Push Through!</h5>
            <h1 style="font-size:50px;color:white;">Summer Sale<br><span>70% off</span></h1>
            <a href="shop.php" class="btn btn-dark">Shop Now</a>
          </div>
        </div>
      </div>
    </div>
  </div>


  <div class="container">
    <div class="row">
      <div class=" col-lg-3">
        <div id="demo" class="carousel slide" data-ride="carousel">

          <!-- Indicators -->
          <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
          </ul>

          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="border py-4 px-3 ha_sale_box">
                <img src="images/shop.png" alt="shop">
                <h2>70% off</h2>
                <p>Bags, Clothing, T-Shirts, Shoes, Watches and much more...</p>
                <a href="shop.php" class="btn btn-dark">Shop Now</a>
              </div>
            </div>
            <div class="carousel-item">
              <div class="border py-4 px-3 ha_sale_box">
                <img src="images/shop2.jpg" alt="shop">
                <h2>70% off</h2>
                <p>Top brands cameras and much more exciting</p>
                <a href="shop.php" class="btn btn-dark">Shop Now</a>
              </div>
            </div>
          </div>

          <!-- Left and right controls -->
          <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
          </a>
          <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
          </a>
        </div>

        <div class="newsletter_info_box my-3">
          <div class="text-center">
            <h5 class="text-dark form-group font-weight-bold">Subscribe Newsletter</h5>
            <p class="form-group">Get all the latest information on Events, Sales and Offers.</p>
            <input type="emmail" class="form-control" name="" id="">
            <a href="#" class="btn btn-dark mt-4">Subscribe</a>
          </div>
        </div>

        <div class="ha_ceo_box my-3">
          <div>
            <div class="d-flex">
              <img src="images/hamza.jpeg" class="float-left mr-2" style="height:80px;border-radius: 40px;" alt="">
              <h6 class="mt-3"><span class="font-weight-bold"> Hamza Fiaz</span><br>CEO & FOUNDER</h6>
            </div>
            <p style="line-height: 1.4rem;padding: 30px 11px 0px;"><span
                style="font-size: 45px;font-weight: bold;">"</span>Lorem ipsum dolor sit amet consectetur adipisicing
              elit. Magnam corrupti repellendus dicta.</p>
          </div>
        </div>



      </div>
      <div class="col-lg-9 border py-5">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="cus_banners_box zoom">
                <img src="images/get1.png" alt="">
                <div>
                  <h4 class="font-weight-bold">Porto Watches</h4>
                  <del class="font-weight-bold d-inline-block">20%</del>
                  <h3 class="font-weight-bold d-inline-block text-primary my-1">30% OFF</h3><br><br>
                  <a href="#" class="font-weight-bold ">Shop Now</a>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="cus_banners_box zoom">
                <img src="images/get1.png" alt="">
                <div>
                  <h4 class="font-weight-bold">DEAL PROMOS</h4>
                  <h6 class="my-1">STARTING AT $99</h6><br>
                  <a href="#" class="font-weight-bold mt-3">Shop Now</a>
              </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="cus_banners_box zoom">
                <img src="images/get1.png" alt="">
                <div>
                  <h4 class="font-weight-bold">Handbags</h4>
                  <h6 class="my-1">STARTING AT $99</h6><br>
                  <a href="#" class="font-weight-bold mt-3">Shop Now</a>
              </div>
              </div>
            </div>
          </div>
      <h3 class="my-5">Latest Products</h3>
      <div class="row pb-4 mt-4 border-bottom">
        <?php
        show_products(); 
        ?>
            
          </div>

          <hr color="#777;">

          <div class="row my-5">
            <div class="col-lg-3 col-md-3">
              <img src="images/brand1.png" alt="">
            </div>
            <div class="col-lg-3 col-md-3">
              <img src="images/brand2.png" alt="">
            </div>
            <div class="col-lg-3 col-md-3">
              <img src="images/brand4.png" alt="">
            </div>
            <div class="col-lg-3 col-md-3">
              <img src="images/brand3.png" alt="">
            </div>
          </div>

          <div class="row text-center my-4">
          <div class="col-lg-4">
            <div class="hf-help_box ">
              <i class="fa fa-headphones text-primary" style="border: 2px solid #289ad4;"></i>
            </div>
            <div class="hf-help_box-info text-center px-2 my-2">
              <h5 class="font-weight-bold">CUSTOMER SUPPORT</h5>
              <h6 class="font-weight-bold mt-1 mb-2">Need Assisstence</h6>
              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quia, perspiciatis! Et excepturi</p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="hf-help_box ">
              <i class="fa fa-credit-card text-primary" style="border: 2px solid #289ad4;"></i>
            </div>
            <div class="hf-help_box-info text-center px-2 my-2">
              <h5 class="font-weight-bold">SECURED PAYMENT</h5>
              <h6 class="font-weight-bold mt-1 mb-2">Safe & Fast</h6>
              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quia, perspiciatis! Et excepturi</p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="hf-help_box ">
              <i class="fa fa-arrow-right text-primary" style="border: 2px solid #289ad4;"></i>
            </div>
            <div class="hf-help_box-info text-center px-2 my-2">
              <h5 class="font-weight-bold">RETURNS</h5>
              <h6 class="font-weight-bold mt-1 mb-2">Easy & Free</h6>
              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quia, perspiciatis! Et excepturi</p>
            </div>
          </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>

<?php
  include "partials/footer.php"

?>

</body>

</html>
