<?php
include "db.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include "links.php";
    ?>
    <title>Add Products</title>
</head>

<body class="jumbotron">

    <div class="w-75 m-auto">
        <h2 class="mt-1 mb-4 text center" style="text-align:center;">Add Products Form</h2>
        <form method="POST" action="" enctype="multipart/form-data">
            <table class="table table-striped">
                <tbody>
                    <tr class="form-group">
                        <td>Name</td>
                        <td><input type="text" class="cus_input_style w-75" placeholder="Enter product name" name="pro_name"></td>
                    </tr>
                    <tr class="form-group">
                        <td>Category</td>
                        <td><input type="text" class="cus_input_style w-75" placeholder="Enter product category" name="pro_cat"></td>
                    </tr>
                    <tr class="form-group">
                        <td>Price</td>
                        <td><input type="number" class="cus_input_style w-75" placeholder="Enter product price" name="pro_price"></td>
                    </tr>
                    <tr class="form-group">
                        <td>Description</td>
                        <td><input type="text" class="cus_input_style w-75" placeholder="Enter product description" name="pro_desc"></td>
                    </tr>
                    <tr class="form-group">
                        <td>Image</td>
                        <td><input type="file" class="cus_input_style w-75" placeholder="Select product image" name="pro_image"></td>
                    </tr>
                </tbody>
            </table>
            <button name="submit" class="btn btn-primary">Submit</button>
        </form>


</body>

</html>

<?php
if (isset($_POST['submit'])) {


    $prod_name = $_POST['pro_name'];
    $prod_catg = $_POST['pro_cat'];
    $prod_price = $_POST['pro_price'];
    $prod_desc = $_POST['pro_desc'];
    $filename = $_FILES["pro_image"]["name"];
    $tempname = $_FILES["pro_image"]["tmp_name"];
    $folder = "./upload-images/" . $filename;
    $image_result = move_uploaded_file($tempname, $folder );
    $sql = "INSERT INTO products (prod_name, prod_category, prod_description, prod_price,prod_image) VALUES ('$prod_name', '$prod_catg', '$prod_desc','$prod_price','$image_result')";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "<div class='alert alert-success'>New record created successfully</div>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}


?>




<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <form action="">
                <div class="form-grow">
                    <label for="">name</label>
                </div>
            </form>
        </div>
    </div>
</div>