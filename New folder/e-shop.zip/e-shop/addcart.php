<?php

include "partials/links.php";
include "config/db.php";
include "partials/header.php";
include "functions.php";

addtocart();



?>